package supertrunfo;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alexandre-kde
 */
public class SuperTrunfo {
    
    private ModeloCarta modelo;
    private Carta[] cartas;
    
    private Scanner sc;
    
    private Jogador[] jogadores;
    private int jogadorDaRodada;
    
    private FilaCartas cartasNaMesa;
    
    public void inicializarScanner() {
        sc = new Scanner(System.in);
    }
    
    public void lerModelo() {
        System.out.print("Nome do modelo de cartas: ");
        String nomeModelo = sc.nextLine();
        System.out.print("Número de atributos: ");
        int numAtributos = sc.nextInt();
        modelo = new ModeloCarta(nomeModelo, numAtributos);
        sc.nextLine();
        for (int i = 0; i < numAtributos; i++) {
            String nomeAtributo;
            int min, max;
            System.out.print("Nome do atributo: ");
            nomeAtributo = sc.nextLine();
            System.out.print("Valores mínimo e máximo: ");
            min = sc.nextInt();
            max = sc.nextInt();
            sc.nextLine();
            
            AtributoModelo atr = new AtributoModelo(nomeAtributo, min, max);
            modelo.setAtributo(i, atr);
        }
    }
    
    public void lerCartas() {
        int numCartas = sc.nextInt();
        cartas = new Carta[numCartas];
        
        sc.nextLine(); // posiciona o cursor de leitura na próxima linha
        for (int i = 0; i < numCartas; ++i) {
            String nome = sc.nextLine();
            int[] valores = new int[modelo.getNumAtributos()];
            for (int j = 0; j < modelo.getNumAtributos(); ++j) {
                valores[j] = sc.nextInt();
            }
            sc.nextLine();
            Carta c = new Carta(modelo, nome, valores);
            cartas[i] = c;
        }
    }
    
    public void lerJogadores() {
        System.out.print("Informe o número de jogadores: ");
        int numJogadores = sc.nextInt();
        sc.nextLine();
        jogadores = new Jogador[numJogadores];
        for (int i = 0; i < numJogadores; ++i) {
            System.out.print("Nome do jogador " + (i + 1) + ": ");
            String nome = sc.nextLine();
            jogadores[i] = new Jogador(nome);
        }
    }
    
    public void realizaPartida() {
        fazDistribuicaoInicial();
        int numJogadoresAtivos = jogadores.length;
        while (numJogadoresAtivos > 1) {
            efetuaRodada();
            numJogadoresAtivos = verificaJogadoresAtivos();
        }
        anunciaVencedor();
    }
    
    public void embaralha() {
        List<Carta> listCarta = Arrays.asList(cartas);
        Collections.shuffle(listCarta);
        listCarta.toArray(cartas);
    }
    
    public void embaralha2() {
        Random rand = new Random();
        for (int i = 0; i < cartas.length; ++i) {
            int indiceParaTroca = rand.nextInt(cartas.length);
            Carta aux = cartas[i];
            cartas[i] = cartas[indiceParaTroca];
            cartas[indiceParaTroca] = aux;
        }
    }
    
    public void fazDistribuicaoInicial() {
        embaralha2();
        FilaCartas[] filasJogadores = new FilaCartas[jogadores.length];
        for (int i = 0; i < jogadores.length; ++i) {
            filasJogadores[i] = new FilaCartas();
        }
        for (int i = 0; i < cartas.length; ++i) {
            int indJogador = i % jogadores.length;
            filasJogadores[indJogador].insereCarta(cartas[i]);
        }
        for (int i = 0; i < jogadores.length; ++i) {
            jogadores[i].recebeCartas(filasJogadores[i]);
        }
    }
    
    public int verificaJogadoresAtivos() {
        int numAtivos = 0;
        for (int i = 0; i < jogadores.length; ++i) {
            if (jogadores[i].estaAtivo()) {
                if (!jogadores[i].temCartas()) {
                    jogadores[i].setJogadorAtivo(false);
                } else {
                    ++numAtivos;
                }
            }
        }
        return numAtivos;
    }
    
    public void efetuaRodada() {
        recolheCartaDoJogadorDaRodada();
        exibeCartaDoJogadorDaRodada();
        recolheCartasDosAdversariosAtivos();
        exibeCartasDosAdversariosAtivos();
        identificaVencedorDaRodada();
        entregaCartasAoVencedorDaRodada();
    }
    
    public void recolheCartaDoJogadorDaRodada() {
        Carta carta = jogadores[jogadorDaRodada].jogaCarta();
        cartasNaMesa.insereCarta(carta);
    }
    
    public void recolheCartasDosAdversariosAtivos() {
        
    }
    
    public void entregaCartasAoVencedorDaRodada() {
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SuperTrunfo superTrunfo = new SuperTrunfo();
        superTrunfo.inicializarScanner();
        superTrunfo.lerModelo();
        superTrunfo.lerCartas();
        superTrunfo.lerJogadores();
        
        superTrunfo.realizaPartida();
    }
    
}
